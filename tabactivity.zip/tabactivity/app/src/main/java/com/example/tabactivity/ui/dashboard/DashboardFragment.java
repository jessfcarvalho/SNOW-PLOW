package com.example.tabactivity.ui.dashboard;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import androidx.fragment.app.FragmentActivity;

import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;

import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;



public class MainActivity extends FragmentActivity implements OnMapReadyCallback{

    public final static String DEBUG_TAG="edu.umb.cs443.MYMSG";

    String weatherapi = "https://api.openweathermap.org/data/2.5/weather?q=";
    String api = "&APPID=cc4ae6e545dee0a295a471824c9fdbda";
    String input;
    TextView textView;
    EditText editText;
    String userInput;
    String URL = "";
    JSONObject object;
    double longitude, latitude;

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        MapFragment mFragment=((MapFragment) getFragmentManager().findFragmentById(R.id.map));
        mFragment.getMapAsync(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_settings) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    public void getWeatherInfo(View v){
        textView = (TextView) findViewById(R.id.textView);
        editText = (EditText) findViewById(R.id.editText);
        EditText textInput = (EditText) findViewById(R.id.editText);
        input = textInput.getText().toString();
        TextView textview = (TextView) findViewById(R.id.textView);
        ImageView img=(ImageView) findViewById(R.id.imageView);
        img.setImageBitmap(null);
        ConnectivityManager connMgr = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = connMgr.getActiveNetworkInfo();

        if (networkInfo != null && networkInfo.isConnected()){
            userInput = editText.getText().toString();
            URL = weatherapi + userInput + api;
            new Thread(new downloadThread(URL)).start();
        } else {
            Toast.makeText(getApplicationContext(), "No network connection available", Toast.LENGTH_SHORT);
        }

        CameraUpdate center = CameraUpdateFactory.newLatLng(new LatLng(latitude, longitude));
        CameraUpdate zoom = CameraUpdateFactory.zoomTo(15);
        mMap.moveCamera(center);
        mMap.animateCamera(zoom);
    }

    public String reader(InputStream is, int length) throws IOException, UnsupportedEncodingException {
        Reader reader = null;
        reader = new InputStreamReader(is);
        char[] buffer = new char[length];
        reader.read(buffer);
        return new String(buffer);
    }

    private class downloadThread implements Runnable{
        private String url;
        downloadThread(String URL){this.url=URL;}
        public void run() {
            try {
                downloadJSON(url);
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private String downloadJSON(String myurl) throws IOException {
            InputStream is = null;
            try {
                URL urllink = new URL(myurl);
                HttpURLConnection connection = (HttpURLConnection) urllink.openConnection();
                connection.setRequestMethod("GET");
                connection.setReadTimeout(10000);
                connection.setConnectTimeout(15000);
                int response = connection.getResponseCode();
                Log.i(DEBUG_TAG, "The response is: " + response);
                is = connection.getInputStream();
                int length = 1000;
                String input = reader(is, length);
                object = new JSONObject(input);
                new Thread(new downloadImage()).start();

            } catch (Exception e) {
                Log.i(DEBUG_TAG, e.toString());
            } finally {
                if (is != null) {
                    is.close();
                }
            } return null;
        }
    }

    private class downloadImage implements Runnable{
        private String imageURL = "https://openweathermap.org/img/wn/";
        private String imagepng = ".png";
        public void run() {
            try {
                String imgURL = imageURL + object.getJSONArray("weather").getJSONObject(0).getString("icon")+ imagepng ;
                Bitmap bitmap = downloadURL(imgURL);
                ImageView img= findViewById(R.id.imageView);
                img.post(new Runnable() {
                    @Override
                    public void run() {
                        if(bitmap!=null) img.setImageBitmap(bitmap);
                        else{
                            Log.i(DEBUG_TAG, "returned bitmap is null");}
                    }
                });
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        private Bitmap downloadURL(String myurl) throws IOException {
            InputStream is = null;
            try {
                URL url = new URL(myurl);
                HttpURLConnection connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.connect();
                int response = connection.getResponseCode();
                Log.i(DEBUG_TAG, "The response is: " + response);
                is = connection.getInputStream();
                Bitmap bitmap = BitmapFactory.decodeStream(is);

                String imgURL = "https://openweathermap.org/img/wn/" + object.getJSONArray("weather").getJSONObject(0).getString("icon") + ".png";

                latitude = object.getJSONObject("coord").getDouble("lat");
                String testLat = String.valueOf(latitude);
                longitude = object.getJSONObject("coord").getDouble("lon");
                String testLog = String.valueOf(longitude);

                return bitmap;
            } catch (Exception e) {
                Log.i(DEBUG_TAG, e.toString());
            } finally {
                if (is != null) {
                    is.close();
                }
            } return null;
        }
    }
    @Override
    public void onMapReady(GoogleMap map) {
        this.mMap=map;
    }
}
